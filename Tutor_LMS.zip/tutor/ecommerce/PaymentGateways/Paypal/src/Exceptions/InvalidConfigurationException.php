<?php
namespace Ollyo\PaymentHub\Exceptions;


use RuntimeException;
use Throwable;

final class InvalidConfigurationException extends RuntimeException implements Throwable
{
}