<?php
/**
 * Expire
 *
 * @package TutorPro\Addons
 * @subpackage Zoom\Views
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$_filter = 'expired';

require dirname( __DIR__ ) . '/template/meeting-list-loader.php';

